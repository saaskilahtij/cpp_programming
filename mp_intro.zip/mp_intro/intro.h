#pragma once

#include "RGB/png.h"

#include <string>

void rotate(std::string inputFile, std::string outputFile);
PNG myArt(unsigned int width, unsigned int height);
